#挑选query   让模型从文件中按照标准，挑选出前几条符合我们要求的query，存入文件中，方便后续与profile进行匹配

# from zhipuai import ZhipuAI
import json
from string import Template
import os
import pandas as pd
from openai import OpenAI
from tqdm import tqdm
import requests
import re
import csv
import time

client = OpenAI(
    api_key="xxxxxxxxxxxx",
    base_url="xxxxxxxxxxxxxx"
)

INPUT_DIR = "B_latest_version_dataset/A_cluster/A_cluster_results_1/cluster_full_with_features_A"  # 输入文件夹
OUTPUT_DIR = "B_latest_version_dataset/A_cluster/A_cluster_results_1/A_queries"               # 输出文件夹
BATCH_SIZE = 4            # 每次发送的 query 数量
SLEEP_BETWEEN_CALLS = 1   # 每批之间等待秒数


prompt_v2 = '''
You are an expert in complex problem analysis with a background in computational complexity theory, graph theory, and resource constraint modeling.
Your task is to classify problems by complexity and determine if they require multiple AI agents to solve and explain.
all judgments must be grounded in quantifiable mathematical theory (not subjective intuition)
Analysis Framework:
1. Problem Complexity:
- Simple Problem traits: Single goal, clear solution path, static environment, complete information, 
Computational complexity: P-class problems (polynomial time, < or = O(n log n)), 
Structural complexity of Solution: DAG parallelism of solution plan is 1 (no parallel subtasks) and critical path < single-agent time limit (e.g. 1 hour for LLM reasoning),
Resource demand < single LLM agent's capacity (e.g. total context window < 128k tokens)
- Complex Problem traits: Multiple goals, dynamic environment, uncertain information, interacting variables, conflicting constraints,
Resource demand > single LLM agent's capacity (context window overflow)
2. Multi-Agent Factors:
A problem needs multiple agents if it requires:
- Multiple external tools/APIs (Tool types for one subtask >1 , e.g., code interpreter + database query + visualization tool))
- Parallel subtask execution (DAG parallelism > 1 or subtask count >1 with no sequential dependencies)
- Complex subtask dependencies (Subtask dependency graph edges >2)
- Specialized agent roles (Required skill domains for one subtask > 1 e.g., coding, data analysis, domain expertise)
3. Educational Factors:
Consider if the problem has educational value, such as:
- Related to key concepts of its domain
- Involves problem-solving strategies or methodologies
- Hard to explain without step-by-step reasoning
- Demonstrates application of theoretical principles
Classification Rules:
1. ONLY IF problem has >1 complex traits → "Complex Problem"
2. ONLY IF Complex Problem has >1 multi-agent factors → "multi_agent_required: true"
3. IF the problem has >2 educaational value → "educational value: true"

Query Refinement Rule (for Complex Educational Tasks)
- Only perform query rewriting if ALL the following conditions are met:
    --The query represents a complex problem requiring multiple reasoning or learning steps.
    --The problem naturally must benefit from a multi-agent and an educational approach.
- If these conditions are not met, keep the original query as-is.
- When rewriting is triggered:
    --First summarize the original query accurately and concisely, preserving its core technical intent.
    --Then rewrite it in a teaching-oriented tone, as if the learner is seeking help or guidance.
    --Examples of instructional phrasing include:
        "Can you teach me how to...", 
        "Please show me how to solve...", 
        "Could you explain how to..."
    --The rewritten version must be precise and educational in style, but must not lose the key technical context.
    
Output Format :
```json
[
  {
  "query": "<user_query>",
  "rewritten_query":"<rewritten_user_query or none>",
  "classification": "Complex Problem|Simple Problem",
  "multi_agent_required": true|false,
  "educational_value": true|false,
  "reasoning": {
    "complexity_factors": ["factor1", "factor2", ...],
    "multi_agent_factors": ["factor1", "factor2", ...],
    "educational_factors": ["factor1", "factor2", ...]
    },
  "summary": "Brief explanation"
  },
    {
  "query": "<user_query>",
  "rewritten_query":"<rewritten_user_query or none>",
  "classification": "Complex Problem|Simple Problem",
  "multi_agent_required": true|false,
  "educational_value": true|false,
  "reasoning": {
    "complexity_factors": ["factor1", "factor2", ...],
    "multi_agent_factors": ["factor1", "factor2", ...],
    "educational_factors": ["factor1", "factor2", ...]
    },
  "summary": "Brief explanation"
  }
]
```

'''

# ======== 辅助函数 ========

def ensure_output_file_exists(filepath):
    """确保输出文件存在（若无则创建并写入表头）"""
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    if not os.path.exists(filepath):
        header = [
            'query',
            'rewritten_query',
            'category_code',
            'classification',
            'multi_agent_required',
            'educational_value',
            'complexity_factors',
            'multi_agent_factors',
            'educational_factors',
            'summary'
        ]
        with open(filepath, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(header)
        print(f"已创建输出文件: {filepath}")


def extract_json_from_response(response_content: str):
    """提取模型返回的JSON"""
    try:
        if "```json" in response_content:
            json_str = response_content.split("```json")[1].split("```")[0].strip()
        elif "```" in response_content:
            json_str = response_content.split("```")[1].split("```")[0].strip()
        else:
            json_str = response_content.strip()
        return json.loads(json_str)
    except Exception as e:
        print(f"JSON解析失败: {e}")
        return []


def append_to_csv(data, output_file):
    """追加写入CSV"""
    ensure_output_file_exists(output_file)
    with open(output_file, 'a', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        for item in data:
            try:
                cls = item.get("classification", "")
                if cls == "Simple Problem":
                    category_code = 0
                elif cls == "Complex Problem" and not item.get("multi_agent_required"):
                    category_code = 1
                else:
                    category_code = 2

                writer.writerow([
                    item.get("query", ""),
                    item.get("rewritten_query", ""),
                    category_code,
                    cls,
                    item.get("multi_agent_required", ""),
                    item.get("educational_value", ""),
                    ", ".join(item.get("reasoning", {}).get("complexity_factors", [])),
                    ", ".join(item.get("reasoning", {}).get("multi_agent_factors", [])),
                    ", ".join(item.get("reasoning", {}).get("educational_factors", [])),
                    item.get("summary", "")
                ])
            except Exception as e:
                print(f"跳过无效项: {e}")


def process_file(file_path, output_path):
    """处理单个文件，分批调用模型"""
    df = pd.read_csv(file_path, usecols=["combined_text"], low_memory=False)
    queries = [q.strip() for q in df["combined_text"].dropna().astype(str) if q.strip()]
    total = len(queries)
    if total == 0:
        print(f"文件 {file_path} 无有效query，跳过。")
        return

    print(f"\n正在处理文件: {os.path.basename(file_path)}  共 {total} 条查询")

    for start in range(0, total, BATCH_SIZE):
        end = min(start + BATCH_SIZE, total)
        batch = queries[start:end]
        if not batch:
            continue

        numbered_queries = "\n\n".join([f"{i+1}. {q}" for i, q in enumerate(batch)])
        content = f'''
            See the questions below, which ones are simple and which are complex? give them to me in json format:
            Questions:
            {numbered_queries}
            '''
        try:
            response = client.chat.completions.create(
                model="deepseek-chat",
                messages=[
                    {"role": "system", "content": prompt_v2},
                    {
                        "role": "user",
                        "content": content
                    }
                ]
            )
            response_content = response.choices[0].message.content
            all_json_data = extract_json_from_response(response_content)
            if all_json_data:
                append_to_csv(all_json_data, output_path)
                print(f"批次 {start}-{end} 已写入 {len(all_json_data)} 条")
            else:
                print(f"批次 {start}-{end} 无有效数据")
        except Exception as e:
            print(f"模型调用失败: {e}")

        time.sleep(SLEEP_BETWEEN_CALLS)


def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    files = [f for f in os.listdir(INPUT_DIR) if f.endswith(".csv")]
    if not files:
        print("未找到可处理的CSV文件。")
        return

    print(f"检测到 {len(files)} 个文件，开始批量处理。\n")
    for file_name in tqdm(files, desc="处理中"):
        input_path = os.path.join(INPUT_DIR, file_name)
        output_path = os.path.join(OUTPUT_DIR, f"{os.path.splitext(file_name)[0]}_classified.csv")
        process_file(input_path, output_path)

    print("\n 所有文件处理完成。")


if __name__ == "__main__":
    main()

