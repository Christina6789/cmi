import os
import json
import random
import pandas as pd
from tqdm import tqdm

# ========== 参数配置 ==========
QUERY_DIR = "A_latest_version_dataset/queries_A"       # 存放 query 分类结果的目录
PROFILE_DIR = "A_latest_version_dataset/profiles_A"    # 存放 unique profile 的目录
OUTPUT_DIR = "A_latest_version_dataset/query_match_A"  # 输出匹配结果目录
MIN_PROFILES, MAX_PROFILES = 2, 5              # 每个 query 随机匹配 2~3 个 profile
# =================================


def safe_load_json(path):
    """安全加载 JSON 文件"""
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        print(f"无法解析 JSON 文件 {path}: {e}")
        return []


def process_pair(query_path, profile_path, output_path):
    """处理单对文件"""
    try:
        df = pd.read_csv(query_path)
    except Exception as e:
        print(f"无法读取 CSV 文件 {query_path}: {e}")
        return

    profiles = safe_load_json(profile_path)
    if not profiles:
        print(f"文件 {os.path.basename(profile_path)} 中无有效 profile。")
        return

    # 过滤 category_code == 2 且 query 不为空
    df_filtered = df[df["category_code"] == 2].dropna(subset=["query"])
    if df_filtered.empty:
        print(f"文件 {os.path.basename(query_path)} 无 category_code==2 的记录，跳过。")
        return

    results = {}
    for i, row in enumerate(df_filtered.itertuples(), 1):
        num_profiles = random.randint(MIN_PROFILES, MAX_PROFILES)
        chosen = random.sample(profiles, min(num_profiles, len(profiles)))

        query_text = str(row.rewritten_query).strip() if pd.notna(row.rewritten_query) else str(row.query).strip()
        if not query_text:
            continue

        results[f"query_{i}"] = {
            "query": query_text,
            "selected_profiles": [
                {
                    "learner": {
                        "self_description": p.get("about_me", "").strip(),
                        "skills": p.get("top_tags", [])
                    }
                }
                for p in chosen if p.get("about_me")
            ]
        }

    if not results:
        print(f"文件 {os.path.basename(query_path)} 无可用匹配结果。")
        return

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

    print(f"已生成 {len(results)} 条匹配结果: {os.path.basename(output_path)}")


def extract_prefix(filename: str):
    """提取 cluster_XXX_full_with_features 前缀"""
    return filename.split("_classified.csv")[0] if filename.endswith("_classified.csv") else \
           filename.split("_unique_profiles.json")[0]


def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    query_files = [f for f in os.listdir(QUERY_DIR) if f.endswith("_classified.csv")]
    profile_files = [f for f in os.listdir(PROFILE_DIR) if f.endswith("_unique_profiles.json")]

    if not query_files or not profile_files:
        print("未找到输入文件，请检查目录。")
        return

    # 构建 prefix 索引
    query_map = {extract_prefix(f): f for f in query_files}
    profile_map = {extract_prefix(f): f for f in profile_files}

    # 找出匹配前缀
    matched_prefixes = sorted(set(query_map.keys()) & set(profile_map.keys()))
    if not matched_prefixes:
        print("未找到匹配前缀的文件对。")
        return

    print(f"检测到 {len(matched_prefixes)} 对匹配文件。\n")

    for prefix in tqdm(matched_prefixes, desc="批量匹配处理中"):
        query_file = query_map[prefix]
        profile_file = profile_map[prefix]

        query_path = os.path.join(QUERY_DIR, query_file)
        profile_path = os.path.join(PROFILE_DIR, profile_file)
        output_name = f"{prefix}_match_profiles.json"
        output_path = os.path.join(OUTPUT_DIR, output_name)

        print(f"\n当前匹配对：")
        print(f"  Query:   {query_file}")
        print(f" Profile: {profile_file}")

        process_pair(query_path, profile_path, output_path)

    print("\n所有匹配任务完成。输出目录：", OUTPUT_DIR)


if __name__ == "__main__":
    main()
