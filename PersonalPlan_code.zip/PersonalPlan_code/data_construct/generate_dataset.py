import os
import json
import re
import requests
from tqdm import tqdm

# ==================== 参数配置 ====================
INPUT_DIR = "file path"     # 输入文件夹（存放 query_match_profile.json）
OUTPUT_FILE = "file path"  # 统一输出文件
os.makedirs(os.path.dirname(OUTPUT_FILE), exist_ok=True)

url = 'xxxxxxxxxxxxxxx'
api_key = 'xxxxxxxxxxxxxxxxxx'

headers = {
    'Content-Type': 'application/json',
    'Authorization': f'Bearer {api_key}'
}

# ========== 系统提示 ==========
prompt = '''
You are an AI Architect for personalized, multi-agent programming instruction.

**Task**
Generate a personalized structured execution plan (JSON only) based on the learner’s provided query and profile.
The plan should be tailored to the learner’s skills, self_description, transforming the query into an effective,efficient and personalized learning multi-agent system.
The output structure should refer to the output format, and for the tools section, select from the provided tools.

**Core Requirements**
--Each subtask must be assigned to exactly one unique agent, 
    --Each agent must possess unique capabilities represented by its tools.
　  --Every agent must have at least one exclusive tool that no other agent uses, reflecting its distinct instructional strength.
    --Agents should be complementary — together forming a cooperative learning system where each specializes in a different stage or perspective of the task.
--There is no overlapping part between the subtasks.
--Tools must be chosen to match both the agent’s pedagogical role and the learner’s skill profile.

**Reflection**
--After generating the complete JSON, you must review your own output and verify that:
    --Structure validity
        --JSON is syntactically correct.
        --No overlapping subtasks or undefined references exist.
    --Tool compliance
        --Every tool is from the provided TOOL_POOL.
    --Pedagogical coherence
        --The subtasks forms a meaningful learning process.
        --Follow a logical educational plan.
If any violation is found, regenerate or adjust the JSON internally until all checks pass.
Only return the final validated JSON — no explanations or natural language output.

**Tool Constraints**
   --Agents may use only tools from this pool:
{
  "CodeInterpreterTool": "Execute and interpret Python or R code for interactive learning and debugging",
  "CodeDocsSearchTool": "Search official documentation and API references",
  "GithubSearchTool": "Retrieve real-world code examples",
  "PDFSearchTool": "Access textbook or research material",
  "DOCXSearchTool": "Analyze Word-based content",
  "MDXSearchTool": "Search Markdown tutorials",
  "JSONSearchTool": "Handle structured JSON data",
  "CSVSearchTool": "Explore CSV datasets for exercises",
  "TXTSearchTool": "Analyze logs or outputs",
  "FileReadTool": "Read and extract code/configuration files",
  "DirectoryReadTool": "Explore project structures",
  "WebsiteSearchTool": "Retrieve online documentation",
  "ScrapeElementFromWebsiteTool": "Demonstrate web scraping",
  "LlamaIndexTool": "Integrate structured retrieval for contextual learning",
  "RagTool": "Provide contextual feedback through retrieval-augmented generation"
}

---

### Output Format (Structured JSON only)
{
  "input": {
    "query": "<learning or programming task>",
    "learner": {
      "self_description": "Brief experience or education summary",
      "skills": ["<languages or tools>"],
    }
  },
  "output": {
    "agents": [
      {
        "agent_role": "<agent role>",
        "goal": "<agent objective>",
        "description": "<agent background or alignment>",
        "tools": ["<tool1>", "<tool2>"]
      }
    ],
    "subtasks": [
      {
        "id": "S1",
        "name": "<stage name>",
        "subtask_objective": "<purpose or focus>",
        "agent":"<agent_name(role)>",
        "steps": [
          {"id": "S1-1", "objective": "<specific task>", "tool": "tool of the agent", "depends_on": ["the steps  depend on"]},
          {"id": "S1-2", "objective": "<specific task>", "tool": "tool of the agent", "depends_on": ["the steps  depend on"]}
        ]
      },
      {
        "id": "S2",
        "name": "<stage name>",
        "subtask_objective": "<purpose or focus>",
        "agent":"<agent_name(role)>",
        "steps": [
          {"id": "S2-1", "objective": "<specific task>", "tool": "tool of the agent","depends_on": ["the steps you depend on"]}
        ]
      }
    ],
  }
}


---

Guidelines:
- Return only JSON.

'''

# =================================================


def build_content(query, learner):
    """构造 content 内容"""
    learner_json = json.dumps(learner, ensure_ascii=False, indent=2)
    return f'''
Please design a personalized multi-agent teaching system for the following input:

"query": "{query}",
"learner_profile": {learner_json}

Return only the JSON result as described in the system prompt.
'''


def extract_all_json_from_marked_text(marked_text):
    """提取所有 ```json ... ``` 中的 JSON 对象"""
    pattern = r'```json\s*(.*?)\s*```'
    matches = re.findall(pattern, marked_text, re.DOTALL)
    json_list = []
    for idx, js in enumerate(matches, 1):
        try:
            json_data = json.loads(js)
            json_list.append(json_data)
        except json.JSONDecodeError:
            continue
    return json_list


def process_file(input_path, out_f):
    """处理单个文件，将结果写入统一输出文件"""
    try:
        with open(input_path, "r", encoding="utf-8") as f:
            query_data = json.load(f)
    except Exception as e:
        print(f"无法读取 {input_path}: {e}")
        return

    for qkey, qinfo in tqdm(query_data.items(), desc=os.path.basename(input_path)):
        query_text = qinfo.get("query", "").strip()
        if not query_text:
            continue
        profiles = qinfo.get("selected_profiles", [])

        for learner_item in profiles:
            learner = learner_item.get("learner", {})
            if not learner.get("self_description"):
                continue

            content = build_content(query_text, learner)
            data = {
                "model": "claude-3-7-sonnet-20250219",
                "messages": [
                    {"role": "system", "content": prompt},
                    {"role": "user", "content": content}
                ]
            }

            try:
                response = requests.post(url, headers=headers, json=data, timeout=180)
                response_data = response.json()
                if "choices" not in response_data:
                    print("无有效响应，跳过该项。")
                    continue

                llm_output = response_data["choices"][0]["message"]["content"]
                print("llm_output:",llm_output)
                json_objs = extract_all_json_from_marked_text(llm_output)
                    
                if not json_objs:
                    continue

                for obj in json_objs:
                    out_f.write(json.dumps(obj, ensure_ascii=False) + "\n")

                print(f"完成: {qkey} × {learner.get('self_description')[:40]}...")

            except Exception as e:
                print(f"请求失败: {e}")
                continue


def main():
    input_files = [f for f in os.listdir(INPUT_DIR) if f.endswith(".json")]
    if not input_files:
        print("未找到任何输入文件。")
        return

    print(f"检测到 {len(input_files)} 个文件，将依次处理并写入：{OUTPUT_FILE}\n")

    with open(OUTPUT_FILE, "a", encoding="utf-8") as out_f:
        for file in input_files:
            input_path = os.path.join(INPUT_DIR, file)
            print(f"\n 当前文件: {file}")
            process_file(input_path, out_f)

    print(f"\n 所有文件处理完成，结果已汇总保存到：{OUTPUT_FILE}")


if __name__ == "__main__":
    main()
