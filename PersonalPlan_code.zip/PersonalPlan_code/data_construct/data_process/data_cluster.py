#聚类处理
from sklearn.decomposition import PCA
import pandas as pd
import numpy as np
import json, os, warnings
from tqdm import tqdm
from collections import Counter
from keybert import KeyBERT
from sklearn.feature_extraction.text import CountVectorizer
from sentence_transformers import SentenceTransformer, util
from umap import UMAP
import hdbscan
import matplotlib.pyplot as plt
import torch
from sklearn.manifold import MDS
from sklearn.preprocessing import normalize

warnings.filterwarnings("ignore")

# ==================== 参数配置 ====================
MODEL_NAME = "all-MiniLM-L6-v2"
TOP_N_KEYWORDS = 10
MIN_CLUSTER_SIZE = 20
MIN_SAMPLES = 10
BATCH_SIZE = 64  # GPU 分批计算 batch 大小

INPUT_CSV = "stackoverflow_data_about_me_top_tag_cleaned_filter_Latest_V1.csv"
OUTPUT_KEYWORD_CSV = "A_SO_cluster_latest/stackoverflow_with_keywords.csv"
OUTPUT_KEYWORD_FREQ = "A_SO_cluster_latest/stackoverflow_keyword_frequency.csv"
OUTPUT_JSON = "A_SO_cluster_latest/keyword_clusters_combined.json"
OUTPUT_ENRICHED_CSV = "A_SO_cluster_latest/stackoverflow_with_keywords_enriched.csv"
VISUAL_OUTPUT = "A_SO_cluster_latest/keyword_cluster_visualization.png"
CLUSTER_EXPORT_DIR = "A_SO_cluster_latest/clusters"

# ==================== 设备检测 ====================
device = "cuda" if torch.cuda.is_available() else "cpu"
print(f"当前计算设备: {device.upper()}")

# ==================== Step 1: 加载模型与数据 ====================
print("加载模型与数据 ...")
model = SentenceTransformer(MODEL_NAME, device=device)
kw_model = KeyBERT(model=model)
# errors='ignore',
df = pd.read_csv(
    INPUT_CSV,
    dtype=str,
    encoding="utf-8",
    encoding_errors="ignore"
)
df.columns = [c.strip().lower() for c in df.columns]

if "question_title" not in df.columns or "question_body" not in df.columns:
    raise ValueError("缺少 question_title 或 question_body 列！")

df = df.dropna(subset=["question_title", "question_body"]).reset_index(drop=True)

# ==================== Step 2: 构造 combined_text ====================
df["combined_text"] = (
    df["question_title"].astype(str) + ". " + df["question_body"].astype(str)
).str.strip()

# ==================== Step 3: 提取关键词 ====================
print("正在提取关键词 ...")
#将文本转化为词频向量
custom_vectorizer = CountVectorizer(
    ngram_range=(1, 3),
    token_pattern=r"(?u)\b\w+\b",
    stop_words="english"
)

def extract_keywords(text, top_n=TOP_N_KEYWORDS):
    if not isinstance(text, str) or len(text) < 5:
        return []
    try:
        keywords = kw_model.extract_keywords(
            text,
            vectorizer=custom_vectorizer,
            use_mmr=True,
            diversity=0.6,
            top_n=top_n
        )
        return [kw for kw, _ in keywords]
    except Exception as e:
        print(f"关键词提取错误: {e}")
        return []

tqdm.pandas(desc="Extracting keywords")
df["keywords"] = df["combined_text"].progress_apply(extract_keywords)

df.to_csv(OUTPUT_KEYWORD_CSV, index=False)
print(f"已保存关键词增强文件：{OUTPUT_KEYWORD_CSV}")

# ==================== Step 4: 统计关键词频率 ====================
print("正在统计关键词频率 ...")
all_keywords = [kw for kws in df["keywords"] for kw in kws if isinstance(kws, list)]
keyword_counter = Counter(all_keywords)
keyword_stats = pd.DataFrame(keyword_counter.most_common(), columns=["keyword", "count"])
keyword_stats.to_csv(OUTPUT_KEYWORD_FREQ, index=False)
print(f"关键词频率文件已保存：{OUTPUT_KEYWORD_FREQ}")

# ==================== Step 5: 计算嵌入 / 相似度矩阵 ====================
def compute_keyword_embedding(keywords, model):
    if not keywords or not isinstance(keywords, list):
        return np.zeros(model.get_sentence_embedding_dimension())
    vectors = model.encode(keywords, convert_to_numpy=True, normalize_embeddings=True, device=device)
    return np.mean(vectors, axis=0)


# if SIMILARITY_MODE == "average":
print("正在计算平均关键词嵌入 ...")
df["embedding"] = df["keywords"].apply(lambda kws: compute_keyword_embedding(kws, model))
embeddings = np.vstack(df["embedding"].to_numpy())
pca_embeddings = PCA(n_components=50, random_state=42).fit_transform(embeddings)
umap_embeddings = UMAP(n_neighbors=20, n_components=10, metric="cosine", random_state=42).fit_transform(pca_embeddings)
clustering_input = umap_embeddings


# ==================== Step 6: 聚类 ====================
print("正在执行 HDBSCAN 聚类 ...")
X = normalize(clustering_input)

clusterer = hdbscan.HDBSCAN(min_cluster_size=MIN_CLUSTER_SIZE, min_samples=MIN_SAMPLES, metric="euclidean",cluster_selection_method='eom').fit(X)

df["cluster_id"] = clusterer.labels_
cluster_labels = clusterer.labels_
valid_clusters = sorted([c for c in set(cluster_labels) if c != -1])
num_clusters = len(valid_clusters)
print(f"聚类完成: {num_clusters} 个簇（噪声点 {np.sum(cluster_labels == -1)} 条）")

# ==================== Step 7: 计算簇内相似度 ====================
print("正在计算簇内平均相似度 ...")
def mean_intra_cluster_similarity(vectors, labels):
    cluster_scores = {}
    for cid in np.unique(labels):
        # if cid == -1: continue
        idx = np.where(labels == cid)[0]
        if len(idx) < 2: continue
        sims = util.cos_sim(
            torch.tensor(vectors[idx]).to(device),
            torch.tensor(vectors[idx]).to(device)
        ).cpu().numpy()
        cluster_scores[cid] = float(np.mean(sims))
    return cluster_scores

cluster_sims = mean_intra_cluster_similarity(embeddings, cluster_labels)

avg_sim = np.mean(list(cluster_sims.values())) if cluster_sims else 0
print(f"平均簇内相似度 ≈ {avg_sim:.3f}")

# ==================== Step 8: 导出 JSON ====================
cluster_results = []
for cid in valid_clusters:
    sub_df = df[df["cluster_id"] == cid]
    merged_keywords = sum(sub_df["keywords"], [])
    representative_keywords = Counter(merged_keywords).most_common(10)
    cluster_results.append({
        "cluster_id": int(cid),
        "size": len(sub_df),
        "mean_similarity": round(cluster_sims.get(cid, 0), 3),
        "top_keywords": [k for k, _ in representative_keywords],
        "sample_queries": sub_df["combined_text"].drop_duplicates().tolist()
    })

with open(OUTPUT_JSON, "w", encoding="utf-8") as f:
    json.dump(cluster_results, f, ensure_ascii=False, indent=2)
print(f"聚类结果 JSON 已保存：{OUTPUT_JSON}")

# ==================== Step 9: enriched 输出 ====================
df_sorted = df.sort_values(by="cluster_id", ascending=True, na_position="last")
base_cols = ["question_id", "question_title", "question_body"]
extra_cols = ["keywords", "combined_text", "cluster_id"]
final_cols = [c for c in (base_cols + extra_cols) if c in df_sorted.columns]
other_cols = [c for c in df_sorted.columns if c not in final_cols]
df_sorted = df_sorted[final_cols + other_cols]
df_sorted.to_csv(OUTPUT_ENRICHED_CSV, index=False, encoding="utf-8-sig")
print(f"enriched 文件已生成：{OUTPUT_ENRICHED_CSV}")

# ==================== Step 10: 每簇导出 ====================
os.makedirs(f"{CLUSTER_EXPORT_DIR}/json", exist_ok=True)
# 先保存正常簇
for cid in valid_clusters:
    sub = df_sorted[df_sorted["cluster_id"] == cid].copy()
    sub.to_csv(os.path.join(CLUSTER_EXPORT_DIR, f"cluster_{cid}_full.csv"), index=False, encoding="utf-8-sig")
    sub.to_json(os.path.join(CLUSTER_EXPORT_DIR, "json", f"cluster_{cid}_all.json"), orient="records", force_ascii=False, indent=2)
# 额外保存噪声点（cluster_id == -1）
noise_df = df_sorted[df_sorted["cluster_id"] == -1].copy()
if len(noise_df) > 0:
    noise_csv = os.path.join(CLUSTER_EXPORT_DIR, "cluster_noise_full.csv")
    noise_json = os.path.join(CLUSTER_EXPORT_DIR, "json", "cluster_noise_all.json")
    noise_df.to_csv(noise_csv, index=False, encoding="utf-8-sig")
    noise_df.to_json(noise_json, orient="records", force_ascii=False, indent=2)
    print(f"已导出噪声点 {len(noise_df)} 条 -> {noise_csv}")
else:
    print("无噪声点。")

print(f"所有簇（含噪声）文件导出完毕：{CLUSTER_EXPORT_DIR}")

# ==================== Step 11: 可视化 ====================
print("生成聚类可视化图 ...")

umap_2d = UMAP(n_neighbors=15, n_components=2, metric="cosine", random_state=42).fit_transform(embeddings)


plt.figure(figsize=(10, 8))
colors = plt.cm.tab20(np.linspace(0, 1, len(valid_clusters)))
for i, cid in enumerate(valid_clusters):
    mask = (cluster_labels == cid)
    plt.scatter(
        umap_2d[mask, 0], umap_2d[mask, 1],
        s=15, color=colors[i % len(colors)], alpha=0.7, label=f"Cluster {cid}"
    )

plt.title(f"Keyword Semantic Clusters ({num_clusters} clusters, -1 excluded)", fontsize=13)
plt.legend(markerscale=2, fontsize=8, bbox_to_anchor=(1.05, 1), loc="upper left")
plt.tight_layout()
plt.savefig(VISUAL_OUTPUT, dpi=300)
plt.close()

print(f"聚类可视化图已保存：{VISUAL_OUTPUT}")

print("\n所有步骤完成！")