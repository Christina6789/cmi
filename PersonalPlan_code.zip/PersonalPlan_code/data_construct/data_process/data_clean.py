import os
import re
import pandas as pd

# ========= 配置 =========
INPUT_FILE  = "stackoverflow_data_about_me_top_tag_cleaned_filter_top_tags_Latest_V1.csv"
OUTPUT_FILE = "stackoverflow_data_about_me_top_tag_cleaned_filter_Latest_V1.csv"

# ========= 文本清洗函数 =========
def clean_text(text):
    if not isinstance(text, str):
        return text
    # 去 HTML 标签
    text = re.sub(r"<[^>]*>", " ", text)
    # 去控制字符
    text = re.sub(r"[\x00-\x1F\x7F]", " ", text)
    # 去非常见字符（保留中英数和常见标点）
    text = re.sub(r"[^a-zA-Z0-9\u4e00-\u9fa5\s.,!?;:'\"()\[\]{}@#%&*\-_=+/]", " ", text)
    # 压缩空白
    text = re.sub(r"\s+", " ", text).strip()
    return text

# ========= top_tags 规则 =========
def is_top_tags_invalid(x: str) -> bool:
    """为空 或 不含 'tag_name' 即判为无效"""
    if x is None:
        return True
    s = str(x).strip().strip('"').strip("'")
    if s == "" or s.lower() in {"na", "nan", "none", "null"}:
        return True
    if s in {"[]", "{}", "[ ]", "{ }"}:
        return True
    if "tag_name" not in s:
        return True
    return False

def main():
    # 读取
    df = pd.read_csv(INPUT_FILE, dtype=str, encoding="utf-8-sig")
    print(f"读取完成：{len(df)} 行，{len(df.columns)} 列")

    # 删除 top_tags 为空或不含 tag_name 的行
    if "top_tags" not in df.columns:
        raise KeyError("未找到列 'top_tags'，无法按要求过滤。")
    before = len(df)
    df = df[~df["top_tags"].apply(is_top_tags_invalid)]
    print(f"删除 top_tags 为空或不含 'tag_name' 的行：{before - len(df)}")
    
    if "question_id" in df.columns:
        before = len(df)
        df = df.drop_duplicates(subset=["question_id"], keep="first")
        print(f"去重完成（按 question_id）：删除 {before - len(df)} 条重复行")
    else:
        print("未找到列 'question_id'，跳过去重。")

    # 全表文本清洗
    for col in df.columns:
        df[col] = df[col].apply(clean_text)

    # 保存
    os.makedirs(os.path.dirname(OUTPUT_FILE) or ".", exist_ok=True)
    df.to_csv(OUTPUT_FILE, index=False, encoding="utf-8")
    print(f"已保存清洗结果：{OUTPUT_FILE}（{len(df)} 行，{len(df.columns)} 列）")

if __name__ == "__main__":
    main()