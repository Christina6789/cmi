import os
import json
import numpy as np
import pandas as pd
from tqdm import tqdm
from sentence_transformers import SentenceTransformer
from scipy.spatial.distance import cdist

# ===== 参数配置 =====
INPUT_DIR = "A_latest_version_dataset/cluster_full_with_features_A"   # 存放多个输入文件
OUTPUT_DIR = "A_latest_version_dataset/profiles_A"               # 输出文件夹
MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"
TOP_N = 3  # 输出前 N 个最不同的 profile
# =====================


def safe_parse(x):
    """安全解析 JSON 字符串为 dict"""
    if isinstance(x, dict):
        return x
    if not isinstance(x, str) or not x.strip():
        return {}
    try:
        return json.loads(x)
    except Exception:
        return {}


def build_combined_text(feature):
    """
    若 about_me 非空，则拼接 about_me + top_tags；
    若 about_me 为空，返回 None（直接跳过）。
    """
    if not isinstance(feature, dict):
        return None

    about = str(feature.get("about_me", "")).strip()
    if not about or about.lower() in ["none", "null", ""]:
        return None  # 跳过无效 about_me

    tags = feature.get("top_tags", [])
    if isinstance(tags, list):
        tags_text = " ".join(map(str, tags))
    elif isinstance(tags, str):
        tags_text = tags
    else:
        tags_text = ""

    combined = (about + " " + tags_text).strip()
    return combined if combined else None


def process_single_file(input_path, output_path, model):
    """处理单个 CSV 文件"""
    try:
        df = pd.read_csv(input_path, low_memory=False)
    except Exception as e:
        print(f"无法读取文件 {input_path}: {e}")
        return

    if "features" not in df.columns:
        print(f"文件 {os.path.basename(input_path)} 缺少 'features' 列，已跳过。")
        return

    tqdm.pandas(desc=f"解析 {os.path.basename(input_path)}")
    df["key_features"] = df["features"].progress_apply(safe_parse)

    tqdm.pandas(desc="构建 combined_text")
    df["combined"] = df["key_features"].progress_apply(build_combined_text)

    # 过滤掉无效 about_me
    df = df[df["combined"].notna()].reset_index(drop=True)
    valid_count = len(df)
    print(f"有效（含 about_me）profile 数量: {valid_count}")

    if valid_count < 3:
        print(f"文件 {os.path.basename(input_path)} 样本过少，跳过差异度计算。")
        return

    print("生成嵌入向量 ...")
    embeddings = model.encode(df["combined"].tolist(), convert_to_numpy=True, show_progress_bar=False)

    print("计算欧氏距离矩阵 ...")
    dist_matrix = cdist(embeddings, embeddings, metric="euclidean")
    np.fill_diagonal(dist_matrix, np.nan)
    df["uniqueness_score"] = np.nanmean(dist_matrix, axis=1)

    top_df = df.sort_values(by="uniqueness_score", ascending=False).head(TOP_N).reset_index(drop=True)

    results = [
        {
            "rank": int(i + 1),
            "uniqueness_score": float(r["uniqueness_score"]),
            "about_me": r["key_features"].get("about_me"),
            "top_tags": r["key_features"].get("top_tags"),
            "link": r.get("owner_profile_url", "")
        }
        for i, r in top_df.iterrows()
    ]

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

    print(f"已保存结果到: {output_path}\n")


def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    files = [f for f in os.listdir(INPUT_DIR) if f.endswith(".csv")]

    if not files:
        print("未在输入目录中发现 CSV 文件。")
        return

    print(f"共检测到 {len(files)} 个文件，开始批量处理。\n")

    model = SentenceTransformer(MODEL_NAME)
    print(f" 模型已加载: {MODEL_NAME}\n")

    for file_name in tqdm(files, desc="批量处理中"):
        input_path = os.path.join(INPUT_DIR, file_name)
        output_name = f"{os.path.splitext(file_name)[0]}_unique_profiles.json"
        output_path = os.path.join(OUTPUT_DIR, output_name)

        process_single_file(input_path, output_path, model)

    print("\n 所有文件处理完成。")


if __name__ == "__main__":
    main()