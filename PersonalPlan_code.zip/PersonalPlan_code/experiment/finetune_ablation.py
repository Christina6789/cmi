#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os, json
import pandas as pd
import torch
from pathlib import Path
from datasets import Dataset
from transformers import (
    Trainer,
    TrainingArguments,
    DataCollatorForSeq2Seq,
    TrainerCallback,
)
from modelscope import AutoTokenizer, AutoModelForCausalLM
from peft import LoraConfig, TaskType, get_peft_model
from collections import OrderedDict
import random

# 设置所有缓存到数据盘
os.environ['MODELSCOPE_CACHE'] = '/root/autodl-tmp/modelscope_cache'
os.environ['HUGGINGFACE_HUB_CACHE'] = '/root/autodl-tmp/huggingface_cache'
os.environ['TRANSFORMERS_CACHE'] = '/root/autodl-tmp/transformers_cache'
os.environ['HF_HOME'] = '/root/autodl-tmp/huggingface'

# 创建目录
os.makedirs('/root/autodl-tmp/modelscope_cache', exist_ok=True)
os.makedirs('/root/autodl-tmp/huggingface_cache', exist_ok=True)
os.makedirs('/root/autodl-tmp/transformers_cache', exist_ok=True)

model_cache_dir = "/root/autodl-tmp/modelscope_cache"

PROMPT = '''
You are an AI Architect for personalized, multi-agent programming instruction.

**Task**
Generate a personalized structured execution plan (JSON only) based on the learner’s provided query and profile.
The plan should be tailored to the learner’s skills, self_description, transforming the query into an effective,efficient and personalized learning multi-agent system.
The output structure should refer to the output format, and for the tools section, select from the provided tools.

**Core Requirements**
--Each subtask must be assigned to exactly one unique agent, 
    --Each agent must possess unique capabilities represented by its tools.
　  --Every agent must have at least one exclusive tool that no other agent uses, reflecting its distinct instructional strength.
    --Agents should be complementary — together forming a cooperative learning system where each specializes in a different stage or perspective of the task.
--There is no overlapping part between the subtasks.
--Tools must be chosen to match both the agent’s pedagogical role and the learner’s skill profile.

**Reflection**
--After generating the complete JSON, you must review your own output and verify that:
    --Structure validity
        --JSON is syntactically correct.
        --No overlapping subtasks or undefined references exist.
    --Tool compliance
        --Every tool is from the provided TOOL_POOL.
    --Pedagogical coherence
        --The subtasks forms a meaningful learning process.
        --Follow a logical educational plan.
If any violation is found, regenerate or adjust the JSON internally until all checks pass.
Only return the final validated JSON — no explanations or natural language output.

**Tool Constraints**
   --Agents may use only tools from this pool:
{
  "CodeInterpreterTool": "Execute and interpret Python or R code for interactive learning and debugging",
  "CodeDocsSearchTool": "Search official documentation and API references",
  "GithubSearchTool": "Retrieve real-world code examples",
  "PDFSearchTool": "Access textbook or research material",
  "DOCXSearchTool": "Analyze Word-based content",
  "MDXSearchTool": "Search Markdown tutorials",
  "JSONSearchTool": "Handle structured JSON data",
  "CSVSearchTool": "Explore CSV datasets for exercises",
  "TXTSearchTool": "Analyze logs or outputs",
  "FileReadTool": "Read and extract code/configuration files",
  "DirectoryReadTool": "Explore project structures",
  "WebsiteSearchTool": "Retrieve online documentation",
  "ScrapeElementFromWebsiteTool": "Demonstrate web scraping",
  "LlamaIndexTool": "Integrate structured retrieval for contextual learning",
  "RagTool": "Provide contextual feedback through retrieval-augmented generation"
}

---

### Output Format (Structured JSON only)
{
  "input": {
    "query": "<learning or programming task>",
    "learner": {
      "self_description": "Brief experience or education summary",
      "skills": ["<languages or tools>"],
    }
  },
  "output": {
    "agents": [
      {
        "agent_role": "<agent role>",
        "goal": "<agent objective>",
        "description": "<agent background or alignment>",
        "tools": ["<tool1>", "<tool2>"]
      }
    ],
    "subtasks": [
      {
        "id": "S1",
        "name": "<stage name>",
        "subtask_objective": "<purpose or focus>",
        "agent":"<agent_name(role)>",
        "steps": [
          {"id": "S1-1", "objective": "<specific task>", "tool": "tool of the agent", "depends_on": ["the steps  depend on"]},
          {"id": "S1-2", "objective": "<specific task>", "tool": "tool of the agent", "depends_on": ["the steps  depend on"]}
        ]
      },
      {
        "id": "S2",
        "name": "<stage name>",
        "subtask_objective": "<purpose or focus>",
        "agent":"<agent_name(role)>",
        "steps": [
          {"id": "S2-1", "objective": "<specific task>", "tool": "tool of the agent","depends_on": ["the steps you depend on"]}
        ]
      }
    ],
  }
}


---

Guidelines:
- Return only JSON.

'''
MAX_LENGTH = 3072

# 重定义json字段顺序 保证按照数据集中的顺序进行读取
def reorder_output(output: dict) -> dict:
    # 1) 规范 agents 的键顺序（可选）
    def order_agent(a: dict) -> OrderedDict:
        keys = ["agent_role", "goal", "description", "tools"]
        od = OrderedDict()
        for k in keys:
            if k in a:
                od[k] = a[k]
        # 把多余的键放到最后，防止信息丢失
        for k, v in a.items():
            if k not in od:
                od[k] = v
        return od

    # 2) 规范 subtasks 的键顺序（你的诉求重点）
    def order_subtask(s: dict) -> OrderedDict:
        keys = ["id", "name", "subtask_objective", "agent","steps"]
        od = OrderedDict()
        for k in keys:
            if k in s:
                od[k] = s[k]
        for k, v in s.items():
            if k not in od:
                od[k] = v
        # steps 内部也可选做一下规范（如需要）
        if "steps" in od and isinstance(od["steps"], list):
            new_steps = []
            for st in od["steps"]:
                if isinstance(st, dict):
                    step_keys = ["id", "objective", "tool", "depends_on"]
                    st_od = OrderedDict()
                    for kk in step_keys:
                        if kk in st: st_od[kk] = st[kk]
                    for kk, vv in st.items():
                        if kk not in st_od: st_od[kk] = vv
                    new_steps.append(st_od)
                else:
                    new_steps.append(st)
            od["steps"] = new_steps
        return od

    out = dict(output)  # 浅拷贝
    if "agents" in out and isinstance(out["agents"], list):
        out["agents"] = [order_agent(a) if isinstance(a, dict) else a for a in out["agents"]]
    if "subtasks" in out and isinstance(out["subtasks"], list):
        out["subtasks"] = [order_subtask(s) if isinstance(s, dict) else s for s in out["subtasks"]]
    return out


# ---------------- 数据预处理 ----------------
def process_func(example):
    query = example["input"]["query"]
    profile = example["input"]["learner"]

    # system / user / assistant
    system = f"<|im_start|>system\n{PROMPT}<|im_end|>\n"
    user = f"<|im_start|>user\nQuery: {query}\nProfile: {json.dumps(profile, ensure_ascii=False)}<|im_end|>\n"
    assistant = "<|im_start|>assistant\n"

    context_text = system + user + assistant
    context_enc = tokenizer(context_text, add_special_tokens=False)
    
    normalized_output = reorder_output(example["output"])
    output_text = json.dumps(normalized_output, ensure_ascii=False)
    response_enc = tokenizer(output_text, add_special_tokens=False)
    
    print("output_text:",output_text)
    input_ids = context_enc["input_ids"] + response_enc["input_ids"] + [tokenizer.eos_token_id]
    attention_mask = context_enc["attention_mask"] + response_enc["attention_mask"] + [1]
    labels = [-100] * len(context_enc["input_ids"]) + response_enc["input_ids"] + [tokenizer.eos_token_id]

    if len(input_ids) > MAX_LENGTH:
        input_ids = input_ids[:MAX_LENGTH]
        attention_mask = attention_mask[:MAX_LENGTH]
        labels = labels[:MAX_LENGTH]

    return {"input_ids": input_ids, "attention_mask": attention_mask, "labels": labels}


# ---------------- 加载 jsonl 文件夹 ----------------
def load_jsonl_folder(folder_path):
    folder = Path(folder_path)
    all_data = []
    for fp in folder.glob("*.jsonl"):
        with open(fp, "r", encoding="utf-8") as f:
            for line in f:
                try:
                    all_data.append(json.loads(line))
                except Exception as e:
                    print(f"[WARN] {fp} skip line: {e}")
    return pd.DataFrame(all_data)


# ---------------- Callback for live inference ----------------


class InferenceCallback(TrainerCallback):
    def __init__(self, tokenizer, raw_eval_dataset, prompt_text, every_n_steps=200, max_retries=3, max_new_tokens=256):
        """
        raw_eval_dataset: 传 '未 map 的验证集'（能取到 sample['input'] 的那个）
        """
        self.tokenizer = tokenizer
        self.raw_eval_dataset = raw_eval_dataset
        self.prompt_text = prompt_text
        self.every_n_steps = every_n_steps
        self.max_retries = max_retries
        self.max_new_tokens = max_new_tokens

    def _build_input(self, query, learner):
        # 与训练 preprocess_func 完全一致的模板（手工拼接）
        system = f"<|im_start|>system\n{self.prompt_text}<|im_end|>\n"
        user = f"<|im_start|>user\nQuery: {query}\nProfile: {json.dumps(learner, ensure_ascii=False)}<|im_end|>\n"
        assistant = "<|im_start|>assistant\n"
        return system + user + assistant

    def on_step_end(self, args, state, control, **kwargs):
        # 从 kwargs 里拿当前 Trainer 的模型（已经挂载了 LoRA，并在持续更新）
        model = kwargs.get("model")
        if model is None:
            return

        # 只在指定步数触发
        if state.global_step == 0 or state.global_step % self.every_n_steps != 0:
            return

        print(f"\n[Sanity Check @ step {state.global_step}]")
        retries, success = 0, False

        while retries < self.max_retries and not success:
            try:
                # 从“未 map 的原始验证集”里取样
                idx = random.randint(0, len(self.raw_eval_dataset) - 1)
                sample = self.raw_eval_dataset[idx]  # 这里要能访问到 sample["input"]

                query = sample["input"]["query"]
                learner = sample["input"]["learner"]

                text = self._build_input(query, learner)
                inputs = self.tokenizer([text], return_tensors="pt").to(model.device)

                was_training = model.training
                model.eval()
                with torch.no_grad():
                    outputs = model.generate(
                        **inputs,
                        max_new_tokens=self.max_new_tokens,
                        eos_token_id=self.tokenizer.eos_token_id,
                        pad_token_id=self.tokenizer.eos_token_id,
                    )
                if was_training:
                    model.train()

                resp = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
                print(f"[Eval Sample idx={idx}]")
                print(f"Query: {query}")
                print(f"Response:\n{resp}")
                success = True

            except Exception as e:
                print(f"[Warning] Failed on eval sample (retry {retries+1}): {e}")
                retries += 1

        if not success:
            print("[Error] All retries failed. Skipping sanity check this round.]")


# ---------------- 主程序 ----------------
if __name__ == "__main__":
    model_name = "qwen/Qwen3-32B"
    # 1. 加载 tokenizer & model
    tokenizer = AutoTokenizer.from_pretrained(model_name, use_fast=False, trust_remote_code=True,
            cache_dir=model_cache_dir)
    if tokenizer.pad_token is None:                                                    
        tokenizer.pad_token = tokenizer.eos_token   
    model = AutoModelForCausalLM.from_pretrained(
        model_name,
        device_map="auto",
        torch_dtype=torch.bfloat16,
        trust_remote_code=True,
        cache_dir=model_cache_dir
    )
    # model.enable_input_require_grads()
    model.gradient_checkpointing_enable()
    # 2. LoRA 配置
    lora_config = LoraConfig(
        task_type=TaskType.CAUSAL_LM,
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj",
                        "gate_proj", "up_proj", "down_proj"],
        inference_mode=False,
        r=16,
        lora_alpha=32,
        lora_dropout=0.05,
    )
    model = get_peft_model(model, lora_config)

    # 3. 加载训练/验证数据
    train_folder = "../dataset_latest/train"
    val_folder = "../dataset_latset/test"

    train_df = load_jsonl_folder(train_folder)
    val_df = load_jsonl_folder(val_folder)

    train_ds = Dataset.from_pandas(train_df)
    val_ds = Dataset.from_pandas(val_df)
    val_ds_raw = Dataset.from_pandas(val_df) 
    train_dataset = train_ds.map(process_func, remove_columns=train_ds.column_names)
    eval_dataset = val_ds.map(process_func, remove_columns=val_ds.column_names)

    # 4. 训练参数
    args = TrainingArguments(
        output_dir="./output_latest_ablation/qwen3-32b-lora_text_only_ablation_Trainer",
        per_device_train_batch_size=2,
        per_device_eval_batch_size=1,
        gradient_accumulation_steps=32,
        eval_strategy="steps",  # 开启验证
        eval_steps=20,               # 每 200 step 验证一次
        logging_steps=20,
        num_train_epochs=3,
        save_steps=40,
        learning_rate=1e-4,
        weight_decay=0.01,
        lr_scheduler_type="cosine",
        warmup_ratio=0.02,
        max_grad_norm=1.0,
        gradient_checkpointing=True,
        bf16=True,
        fp16=False, 
        report_to="tensorboard",
        run_name="qwen3-32b-lora-ablation",
        save_total_limit=2,
        remove_unused_columns=False,
        resume_from_checkpoint=True
    )

    # 5. Trainer
    data_collator = DataCollatorForSeq2Seq(tokenizer=tokenizer, padding=True, label_pad_token_id=-100)
    trainer = Trainer(
        model=model,
        args=args,
        train_dataset=train_dataset,
        eval_dataset=eval_dataset,
        data_collator=data_collator,
        callbacks=[InferenceCallback(tokenizer,val_ds_raw,PROMPT, every_n_steps=200)],
    )

    # 6. 开始训练
    trainer.train()

    # 7. 保存 LoRA adapter
    model.save_pretrained("./output_latest_ablation/qwen3-32b-lora_stage_ablation/final")
    print(" LoRA 微调完成，LoRA 权重已保存到 ./output_latest_ablation/qwen3-32b-lora_stage_ablation/final")
