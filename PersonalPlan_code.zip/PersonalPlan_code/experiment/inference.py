#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Dual LoRA inference (stage1 + stage2) + Batch JSONL processing
- 使用 ModelScope 加载 tokenizer / base model（与训练脚本一致）
- 直接运行，无需命令行参数
- 成功解析 -> 写 {"input": {...}, "output": {...}}
- 解析失败 -> 仅写 {"input": {...}, "output_raw": {"stage2_raw": "..."}}

依赖:
  pip install modelscope peft torch accelerate  # (transformers可选)
"""

import os
import json
import torch
from typing import Dict, Any, Optional

# === 与训练脚本保持一致的加载方式 ===
from modelscope import AutoTokenizer, AutoModelForCausalLM
from peft import PeftModel

# ================== 环境与缓存（与训练脚本一致） ==================
os.environ['MODELSCOPE_CACHE'] = '/root/autodl-tmp/modelscope_cache'
os.environ['HUGGINGFACE_HUB_CACHE'] = '/root/autodl-tmp/huggingface_cache'
os.environ['TRANSFORMERS_CACHE'] = '/root/autodl-tmp/transformers_cache'
os.environ['HF_HOME'] = '/root/autodl-tmp/huggingface'

os.makedirs('/root/autodl-tmp/modelscope_cache', exist_ok=True)
os.makedirs('/root/autodl-tmp/huggingface_cache', exist_ok=True)
os.makedirs('/root/autodl-tmp/transformers_cache', exist_ok=True)

MODEL_CACHE_DIR = "/root/autodl-tmp/modelscope_cache"

# ================== I/O 配置 ==================
TEST_FILE = "dataset/test/H_new.jsonl"                  # 输入测试文件
OUT_FILE  = "dataset/test/H_new_test_results.jsonl"     # 输出文件

# ================== 模型与 LoRA 路径 ==================
# 与训练脚本保持同系列（示例使用 32B；若你实际是 0.6B/7B/14B，请相应替换）
BASE_MODEL = "qwen/Qwen3-32B"

# 注意：STAGE1_LORA_DIR 指向你训练保存的 LoRA 目录（peft adapter）
# 例如：./output_latest/qwen3-32b-lora_stage1/final
STAGE1_LORA_DIR = "./output_latest/qwen3-32b-lora_stage1/final"

# STAGE2 可以是你另一个 LoRA（补 steps 的 LoRA）；若暂时没有，仍可保留目录或与 stage1 相同
STAGE2_LORA_DIR = "./output_latest/qwen3-0.6b-lora_full_output_datafit/final"

# ================== 生成与精度 ==================
def _auto_pick_dtype():
    if torch.cuda.is_available():
        # 优先 bfloat16; 否则 float16
        try:
            if torch.cuda.is_bf16_supported():
                return torch.bfloat16
        except Exception:
            pass
        return torch.float16
    return torch.float32

DTYPE = _auto_pick_dtype()
DEVICE_MAP = "auto"

LOAD_IN_8BIT = False   # 如需 bitsandbytes 量化可改 True（需正确安装）
LOAD_IN_4BIT = False

MAX_NEW_TOKENS_1 = 768
MAX_NEW_TOKENS_2 = 1400
DO_SAMPLE = False      # False：稳定、可复现；True：发散（需配温度/Top-p）
TEMPERATURE = 0.3
TOP_P = 0.9

# ================== Prompts（与训练一致） ==================
PROMPT_STAGE1 = """
You are an AI Architect for personalized, multi-agent programming instruction.

**Task**
Generate a personalized structured execution plan (JSON only) based on the learner’s provided query and profile.
The plan should be tailored to the learner’s skills, self_description, transforming the query into an effective,efficient and personalized learning multi-agent system.
The output structure should refer to the output format, and for the tools section, select from the provided tools.

**Core Requirements**
--Each subtask must be assigned to exactly one unique agent, 
    --Each agent must possess unique capabilities represented by its tools.
　  --Every agent must have at least one exclusive tool that no other agent uses, reflecting its distinct instructional strength.
    --Agents should be complementary — together forming a cooperative learning system where each specializes in a different stage or perspective of the task.
--There is no overlapping part between the subtasks.
--Tools must be chosen to match both the agent’s pedagogical role and the learner’s skill profile.

**Reflection**
--After generating the complete JSON, you must review your own output and verify that:
    --Structure validity
        --JSON is syntactically correct.
        --No overlapping subtasks or undefined references exist.
    --Tool compliance
        --Every tool is from the provided TOOL_POOL.
    --Pedagogical coherence
        --The subtasks forms a meaningful learning process.
        --Follow a logical educational plan.
If any violation is found, regenerate or adjust the JSON internally until all checks pass.
Only return the final validated JSON — no explanations or natural language output.

**Tool Constraints**
   --Agents may use only tools from this pool:
{
  "CodeInterpreterTool": "Execute and interpret Python or R code for interactive learning and debugging",
  "CodeDocsSearchTool": "Search official documentation and API references",
  "GithubSearchTool": "Retrieve real-world code examples",
  "PDFSearchTool": "Access textbook or research material",
  "DOCXSearchTool": "Analyze Word-based content",
  "MDXSearchTool": "Search Markdown tutorials",
  "JSONSearchTool": "Handle structured JSON data",
  "CSVSearchTool": "Explore CSV datasets for exercises",
  "TXTSearchTool": "Analyze logs or outputs",
  "FileReadTool": "Read and extract code/configuration files",
  "DirectoryReadTool": "Explore project structures",
  "WebsiteSearchTool": "Retrieve online documentation",
  "ScrapeElementFromWebsiteTool": "Demonstrate web scraping",
  "LlamaIndexTool": "Integrate structured retrieval for contextual learning",
  "RagTool": "Provide contextual feedback through retrieval-augmented generation"
}

---

### Output Format (Structured JSON only)
{
  "input": {
    "query": "<learning or programming task>",
    "learner": {
      "self_description": "Brief experience or education summary",
      "skills": ["<languages or tools>"],
    }
  },
  "output": {
    "agents": [
      {
        "agent_role": "<agent role>",
        "goal": "<agent objective>",
        "description": "<agent background or alignment>",
        "tools": ["<tool1>", "<tool2>"]
      }
    ],
    "subtasks": [
      {
        "id": "S1",
        "name": "<stage name>",
        "subtask_objective": "<purpose or focus>",
        "agent":"<agent_name(role)>",
      },
      {
        "id": "S2",
        "name": "<stage name>",
        "subtask_objective": "<purpose or focus>",
        "agent":"<agent_name(role)>",
      }
    ],
  }
}

---

Guidelines:
- Return only JSON.
""".strip()

PROMPT_STAGE2 = """
You are an AI Architect for personalized, multi-agent programming instruction.

TASK
Given:
1) The learner input (query + learner profile), and
2) An OutputSkeleton that ALREADY includes the final set of agents and subtasks (each subtask has id/name/subtask_objective/agent but NO steps),

Return ONLY the final JSON object named "output" with the SAME agents and subtasks as the skeleton, but with a filled "steps" array for EACH subtask.

HARD CONSTRAINTS
- DO NOT change, remove, or add any agents or subtasks from the skeleton (id/name/subtask_objective/agent must remain identical).
- For each subtask, steps MUST use ONLY tools that exist in that subtask’s assigned agent’s tools.
- Step IDs MUST follow "<SubtaskID>-<running number>" (e.g., S3-1, S3-2).
- "depends_on" MUST reference existing step IDs (prefer previous steps in the SAME subtask) and be acyclic.
- If a subtask logically needs no steps, return an empty array for that subtask’s "steps".

RETURN FORMAT (JSON only)
{
  "output": {
    "agents": [ ... exactly from the skeleton ... ],
    "subtasks": [
      {
        "id": "S1",
        "name": "...",
        "subtask_objective": "...",
        "agent": "<unchanged>",
        "steps": [
          {"id":"S1-1","objective":"<specific task>","tool":"<tool from assigned agent>","depends_on":[]},
          {"id":"S1-2","objective":"...","tool":"<tool>","depends_on":["S1-1"]}
        ]
      },
      ...
    ]
  }
}

REFLECTION (internal)
- Validate tool usage against the assigned agent’s tools.
- Validate step IDs and depends_on correctness.
- Fix internally if any violation is detected.

Think step-by-step internally, but output ONLY the final JSON.
""".strip()

# ================== 工具函数 ==================
def apply_chat(tokenizer, system_prompt: str, user_content: str) -> str:
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user",   "content": user_content},
    ]
    # Qwen 在 ModelScope 下同样支持 apply_chat_template
    return tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)

def decode_new_only(tokenizer, outputs, inputs) -> str:
    new_tokens = outputs[0][inputs["input_ids"].shape[-1]:]
    return tokenizer.decode(new_tokens, skip_special_tokens=True).strip()

def build_user_content_stage1(query: str, learner: Dict) -> str:
    return f"Query: {query}\nProfile: {json.dumps(learner, ensure_ascii=False)}"

def build_user_content_stage2(query: str, learner: Dict, skeleton_raw: str) -> str:
    return (
        "Input: " + json.dumps({"query": query, "learner": learner}, ensure_ascii=False) + "\n" +
        "OutputSkeletonRaw:\n" + skeleton_raw
    )

# ================== 推理类（ModelScope 版） ==================
class DualAdapterRaw:
    def __init__(self):
        # 1) Tokenizer
        self.tokenizer = AutoTokenizer.from_pretrained(
            BASE_MODEL, use_fast=False, trust_remote_code=True, cache_dir=MODEL_CACHE_DIR
        )
        if self.tokenizer.pad_token is None and self.tokenizer.eos_token is not None:
            self.tokenizer.pad_token = self.tokenizer.eos_token

        # 2) Base model（由 ModelScope 加载，兼容 peft）
        base_kwargs = dict(
            device_map=DEVICE_MAP,
            torch_dtype=DTYPE,
            trust_remote_code=True,
            cache_dir=MODEL_CACHE_DIR,
        )
        # （可选）如你配置了 8bit/4bit 量化并正确安装 bitsandbytes，可在此加入 load_in_8bit / load_in_4bit
        base = AutoModelForCausalLM.from_pretrained(BASE_MODEL, **base_kwargs)

        # 3) pad_token_id 兜底
        if getattr(base.generation_config, "pad_token_id", None) is None and self.tokenizer.pad_token_id is not None:
            base.generation_config.pad_token_id = self.tokenizer.pad_token_id

        # 4) 加载两套 LoRA 适配器（peft）
        if not os.path.isdir(STAGE1_LORA_DIR):
            raise FileNotFoundError(f"STAGE1_LORA_DIR not found: {STAGE1_LORA_DIR}")
        if not os.path.isdir(STAGE2_LORA_DIR):
            raise FileNotFoundError(f"STAGE2_LORA_DIR not found: {STAGE2_LORA_DIR}")

        model = PeftModel.from_pretrained(base, STAGE1_LORA_DIR, adapter_name="stage1")
        model.load_adapter(STAGE2_LORA_DIR, adapter_name="stage2")

        self.model = model.eval()

    @torch.no_grad()
    def _generate(self, system_prompt: str, user_content: str, max_new_tokens: int) -> str:
        text = apply_chat(self.tokenizer, system_prompt, user_content)
        inputs = self.tokenizer([text], return_tensors="pt").to(self.model.device)

        # do_sample=False 时不传温度/Top-p 更干净
        gen_kwargs = dict(
            max_new_tokens=max_new_tokens,
            eos_token_id=self.tokenizer.eos_token_id,
            pad_token_id=self.tokenizer.pad_token_id or self.tokenizer.eos_token_id,
            do_sample=False
        )
        if DO_SAMPLE:
            gen_kwargs.update(dict(do_sample=True, temperature=TEMPERATURE, top_p=TOP_P))

        outputs = self.model.generate(**inputs, **gen_kwargs)
        return decode_new_only(self.tokenizer, outputs, inputs)

    @torch.no_grad()
    def stage1(self, query: str, learner: Dict) -> str:
        self.model.set_adapter("stage1")
        uc = build_user_content_stage1(query, learner)
        try:
            return self._generate(PROMPT_STAGE1, uc, MAX_NEW_TOKENS_1)
        except Exception as e:
            return f"[Stage1-Error] {type(e).__name__}: {e}"

    @torch.no_grad()
    def stage2(self, query: str, learner: Dict, skeleton_raw: str) -> str:
        self.model.set_adapter("stage2")
        uc = build_user_content_stage2(query, learner, skeleton_raw)
        try:
            return self._generate(PROMPT_STAGE2, uc, MAX_NEW_TOKENS_2)
        except Exception as e:
            return f"[Stage2-Error] {type(e).__name__}: {e}"

def compose_infer_raw(query: str, learner: Dict) -> Dict[str, str]:
    runner = DualAdapterRaw()
    s1_raw = runner.stage1(query, learner)
    s2_raw = runner.stage2(query, learner, s1_raw)
    return {"stage1_raw": s1_raw, "stage2_raw": s2_raw}

# ================== 解析工具 ==================
def try_extract_output(stage2_raw: str) -> Optional[Dict[str, Any]]:
    """
    尝试将 stage2_raw 解析为 JSON；若包含 {"output": {...}} 则返回其中的 output，
    否则若其本身是 dict，也作为最终 output 返回；失败则返回 None。
    """
    try:
        obj = json.loads(stage2_raw)
        if isinstance(obj, dict):
            if "output" in obj and isinstance(obj["output"], dict):
                return obj["output"]
            return obj
    except Exception:
        return None
    return None

# ================== 批处理主流程 ==================
def run_batch():
    n_in, n_ok, n_fallback, n_err = 0, 0, 0, 0
    os.makedirs(os.path.dirname(OUT_FILE) or ".", exist_ok=True)

    with open(TEST_FILE, "r", encoding="utf-8") as fin, \
         open(OUT_FILE, "w", encoding="utf-8") as fout:
        for line in fin:
            line = line.strip()
            if not line:
                continue
            n_in += 1

            try:
                item = json.loads(line)
            except Exception:
                fout.write(json.dumps({"_raw": line, "stage_error": "Unparsable JSON line"}, ensure_ascii=False) + "\n")
                n_err += 1
                continue

            inp = item.get("input", {})
            query = inp.get("query")
            learner = inp.get("learner")
            if query is None or learner is None:
                out = dict(item)
                out["stage_error"] = "Missing input.query or input.learner"
                fout.write(json.dumps(out, ensure_ascii=False) + "\n")
                n_err += 1
                continue

            # 两阶段推理
            try:
                outs = compose_infer_raw(query, learner)  # {"stage1_raw": "...", "stage2_raw": "..."}
            except Exception as e:
                out = dict(item)
                out["stage_error"] = f"{type(e).__name__}: {e}"
                fout.write(json.dumps(out, ensure_ascii=False) + "\n")
                n_err += 1
                continue

            stage2_raw = outs.get("stage2_raw", "")
            parsed = try_extract_output(stage2_raw)

            out = dict(item)  # 保留原始字段
            if parsed is not None:
                out["output"] = parsed
                if "output_raw" in out:
                    del out["output_raw"]
                n_ok += 1
            else:
                out["output_raw"] = {"stage2_raw": stage2_raw}
                if "output" in out:
                    del out["output"]
                n_fallback += 1

            fout.write(json.dumps(out, ensure_ascii=False) + "\n")

    print(f"Processed: {n_in} | Parsed OK: {n_ok} | Fallback (output_raw.stage2_raw): {n_fallback} | Errors: {n_err}")
    print(f"Saved -> {OUT_FILE}")

# ================== 入口 ==================
if __name__ == "__main__":
    run_batch()
