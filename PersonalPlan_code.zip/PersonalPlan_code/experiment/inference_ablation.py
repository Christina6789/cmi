#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Batch inference for Qwen + LoRA (ModelScope)
- 输入: JSONL，每行形如 {"input": {"query": "...", "learner": {...}}}
- 输出: JSONL；若成功解析为 JSON，则写 {"input": ..., "output": {...}}
        否则写 {"input": ..., "output_raw": {"stage2_raw": "<model text>"}}

依赖:
  pip install modelscope peft torch accelerate
"""

import os
import json
from typing import Dict, Any, Optional

import torch
from modelscope import AutoTokenizer, AutoModelForCausalLM
from peft import PeftModel

# ================== 路径与环境（按需修改） ==================
# 输入/输出文件
INPUT_FILE  = "/mnt/data/H_new.jsonl"            # 你上传的文件
OUTPUT_FILE = "/mnt/data/H_new_infer_results.jsonl"

# 基座模型与 LoRA 适配器目录（请根据你的训练结果修改）
BASE_MODEL       = "qwen/Qwen3-32B"  # 或 "qwen/Qwen3-0.6B" / "qwen/Qwen3-7B" 等
LORA_ADAPTER_DIR = "./output_latest_ablation/qwen3-32b-lora_stage_ablation/final"

# 缓存目录（与你训练时一致）
os.environ['MODELSCOPE_CACHE']      = '/root/autodl-tmp/modelscope_cache'
os.environ['HUGGINGFACE_HUB_CACHE'] = '/root/autodl-tmp/huggingface_cache'
os.environ['TRANSFORMERS_CACHE']    = '/root/autodl-tmp/transformers_cache'
os.environ['HF_HOME']               = '/root/autodl-tmp/huggingface'
os.makedirs('/root/autodl-tmp/huggingface_cache', exist_ok=True)
os.makedirs('/root/autodl-tmp/transformers_cache', exist_ok=True)
MODEL_CACHE_DIR = "/root/autodl-tmp/modelscope_cache"

# （可选）离线模式，若你已完整缓存模型可打开
# os.environ['MODELSCOPE_HUB_OFFLINE'] = '1'

# ================== 推理参数 ==================
MAX_NEW_TOKENS   = 1200
DO_SAMPLE        = False
TEMPERATURE      = 0.3
TOP_P            = 0.9
DEVICE_MAP       = "auto"

def _auto_pick_dtype():
    if torch.cuda.is_available():
        try:
            if torch.cuda.is_bf16_supported():
                return torch.bfloat16
        except Exception:
            pass
        return torch.float16
    return torch.float32
DTYPE = _auto_pick_dtype()

# ================== 与训练一致的 system prompt ==================
PROMPT = r'''
You are an AI Architect for personalized, multi-agent programming instruction.

**Task**
Generate a personalized structured execution plan (JSON only) based on the learner’s provided query and profile.
The plan should be tailored to the learner’s skills, self_description, transforming the query into an effective,efficient and personalized learning multi-agent system.
The output structure should refer to the output format, and for the tools section, select from the provided tools.

**Core Requirements**
--Each subtask must be assigned to exactly one unique agent, 
    --Each agent must possess unique capabilities represented by its tools.
　  --Every agent must have at least one exclusive tool that no other agent uses, reflecting its distinct instructional strength.
    --Agents should be complementary — together forming a cooperative learning system where each specializes in a different stage or perspective of the task.
--There is no overlapping part between the subtasks.
--Tools must be chosen to match both the agent’s pedagogical role and the learner’s skill profile.

**Reflection**
--After generating the complete JSON, you must review your own output and verify that:
    --Structure validity
        --JSON is syntactically correct.
        --No overlapping subtasks or undefined references exist.
    --Tool compliance
        --Every tool is from the provided TOOL_POOL.
    --Pedagogical coherence
        --The subtasks forms a meaningful learning process.
        --Follow a logical educational plan.
If any violation is found, regenerate or adjust the JSON internally until all checks pass.
Only return the final validated JSON — no explanations or natural language output.

**Tool Constraints**
   --Agents may use only tools from this pool:
{
  "CodeInterpreterTool": "Execute and interpret Python or R code for interactive learning and debugging",
  "CodeDocsSearchTool": "Search official documentation and API references",
  "GithubSearchTool": "Retrieve real-world code examples",
  "PDFSearchTool": "Access textbook or research material",
  "DOCXSearchTool": "Analyze Word-based content",
  "MDXSearchTool": "Search Markdown tutorials",
  "JSONSearchTool": "Handle structured JSON data",
  "CSVSearchTool": "Explore CSV datasets for exercises",
  "TXTSearchTool": "Analyze logs or outputs",
  "FileReadTool": "Read and extract code/configuration files",
  "DirectoryReadTool": "Explore project structures",
  "WebsiteSearchTool": "Retrieve online documentation",
  "ScrapeElementFromWebsiteTool": "Demonstrate web scraping",
  "LlamaIndexTool": "Integrate structured retrieval for contextual learning",
  "RagTool": "Provide contextual feedback through retrieval-augmented generation"
}

---

### Output Format (Structured JSON only)
{
  "input": {
    "query": "<learning or programming task>",
    "learner": {
      "self_description": "Brief experience or education summary",
      "skills": ["<languages or tools>"],
    }
  },
  "output": {
    "agents": [
      {
        "agent_role": "<agent role>",
        "goal": "<agent objective>",
        "description": "<agent background or alignment>",
        "tools": ["<tool1>", "<tool2>"]
      }
    ],
    "subtasks": [
      {
        "id": "S1",
        "name": "<stage name>",
        "subtask_objective": "<purpose or focus>",
        "agent":"<agent_name(role)>",
        "steps": [
          {"id": "S1-1", "objective": "<specific task>", "tool": "tool of the agent", "depends_on": ["the steps  depend on"]},
          {"id": "S1-2", "objective": "<specific task>", "tool": "tool of the agent", "depends_on": ["the steps  depend on"]}
        ]
      },
      {
        "id": "S2",
        "name": "<stage name>",
        "subtask_objective": "<purpose or focus>",
        "agent":"<agent_name(role)>",
        "steps": [
          {"id": "S2-1", "objective": "<specific task>", "tool": "tool of the agent","depends_on": ["the steps you depend on"]}
        ]
      }
    ],
  }
}

---

Guidelines:
- Return only JSON.
'''.strip()

# ================== 文本模板（与训练保持一致：手工拼接 im tokens） ==================
def build_prompt_text(query: str, learner: Dict[str, Any]) -> str:
    system    = f"<|im_start|>system\n{PROMPT}<|im_end|>\n"
    user      = f"<|im_start|>user\nQuery: {query}\nProfile: {json.dumps(learner, ensure_ascii=False)}<|im_end|>\n"
    assistant = "<|im_start|>assistant\n"
    return system + user + assistant

def decode_new_only(tokenizer, outputs, inputs) -> str:
    # 只解码新生成的 token（不回显提示）
    new_tokens = outputs[0][inputs["input_ids"].shape[-1]:]
    return tokenizer.decode(new_tokens, skip_special_tokens=True).strip()

def try_extract_output(text: str) -> Optional[Dict[str, Any]]:
    """
    - 若 text 是 JSON 且包含 {"output": {...}} -> 返回 {...}
    - 若 text 是 JSON 且本身是 dict -> 返回该 dict
    - 其他情况返回 None
    """
    try:
        obj = json.loads(text)
        if isinstance(obj, dict):
            if "output" in obj and isinstance(obj["output"], dict):
                return obj["output"]
            return obj
    except Exception:
        return None
    return None

# ================== 推理 Runner（一次加载，多次复用） ==================
class SingleAdapterRunner:
    def __init__(self):
        # 1) Tokenizer
        self.tokenizer = AutoTokenizer.from_pretrained(
            BASE_MODEL, use_fast=False, trust_remote_code=True, cache_dir=MODEL_CACHE_DIR
        )
        if self.tokenizer.pad_token is None and self.tokenizer.eos_token is not None:
            self.tokenizer.pad_token = self.tokenizer.eos_token

        # 2) Base model
        base_kwargs = dict(
            device_map=DEVICE_MAP,
            torch_dtype=DTYPE,
            trust_remote_code=True,
            cache_dir=MODEL_CACHE_DIR,
        )
        base = AutoModelForCausalLM.from_pretrained(BASE_MODEL, **base_kwargs)

        # 3) pad_token_id 兜底
        if getattr(base.generation_config, "pad_token_id", None) is None and self.tokenizer.pad_token_id is not None:
            base.generation_config.pad_token_id = self.tokenizer.pad_token_id

        # 4) 挂载 LoRA 适配器
        if not os.path.isdir(LORA_ADAPTER_DIR):
            raise FileNotFoundError(f"LORA_ADAPTER_DIR not found: {LORA_ADAPTER_DIR}")
        model = PeftModel.from_pretrained(base, LORA_ADAPTER_DIR)

        self.model = model.eval()

    @torch.no_grad()
    def generate(self, query: str, learner: Dict[str, Any]) -> str:
        text = build_prompt_text(query, learner)
        inputs = self.tokenizer([text], return_tensors="pt").to(self.model.device)

        gen_kwargs = dict(
            max_new_tokens=MAX_NEW_TOKENS,
            eos_token_id=self.tokenizer.eos_token_id,
            pad_token_id=self.tokenizer.pad_token_id or self.tokenizer.eos_token_id,
            do_sample=False,
        )
        if DO_SAMPLE:
            gen_kwargs.update(dict(do_sample=True, temperature=TEMPERATURE, top_p=TOP_P))

        outputs = self.model.generate(**inputs, **gen_kwargs)
        return decode_new_only(self.tokenizer, outputs, inputs)

# ================== 批量主流程 ==================
def run_batch():
    n_in, n_ok, n_fallback, n_err = 0, 0, 0, 0

    # 初始化一次
    try:
        runner = SingleAdapterRunner()
    except Exception as e:
        raise RuntimeError(f"模型初始化失败: {type(e).__name__}: {e}")

    os.makedirs(os.path.dirname(OUTPUT_FILE) or ".", exist_ok=True)

    with open(INPUT_FILE, "r", encoding="utf-8") as fin, \
         open(OUTPUT_FILE, "w", encoding="utf-8") as fout:

        for line in fin:
            raw = line.strip()
            if not raw:
                continue
            n_in += 1

            # 读取一行 JSON
            try:
                item = json.loads(raw)
            except Exception:
                fout.write(json.dumps({"_raw": raw, "stage_error": "Unparsable JSON line"}, ensure_ascii=False) + "\n")
                n_err += 1
                continue

            inp = item.get("input", {})
            query   = inp.get("query")
            learner = inp.get("learner")
            if query is None or learner is None:
                out = dict(item)
                out["stage_error"] = "Missing input.query or input.learner"
                fout.write(json.dumps(out, ensure_ascii=False) + "\n")
                n_err += 1
                continue

            # 推理
            try:
                text = runner.generate(query, learner)
            except Exception as e:
                out = dict(item)
                out["stage_error"] = f"{type(e).__name__}: {e}"
                fout.write(json.dumps(out, ensure_ascii=False) + "\n")
                n_err += 1
                continue

            # 解析
            parsed = try_extract_output(text)
            out = dict(item)  # 保留原字段
            if parsed is not None:
                out["output"] = parsed
                out.pop("output_raw", None)
                n_ok += 1
            else:
                out["output_raw"] = {"stage2_raw": text}
                out.pop("output", None)
                n_fallback += 1

            fout.write(json.dumps(out, ensure_ascii=False) + "\n")

    print(f"Processed: {n_in} | Parsed OK: {n_ok} | Fallback (output_raw.stage2_raw): {n_fallback} | Errors: {n_err}")
    print(f"Saved -> {OUTPUT_FILE}")

# ================== 入口 ==================
if __name__ == "__main__":
    run_batch()
