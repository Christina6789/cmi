#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Full CoT-Style Output Training (fits your data shape):
- Each record has:
  {
    "input": {
      "query": "...",
      "learner": {...},
      "output": {  # <-- THIS IS THE SKELETON (agents + subtasks without steps)
        "agents": [...],
        "subtasks": [{"id","name","subtask_objective","agent"} ...]
      }
    },
    "output": {    # <-- FULL GROUND TRUTH with steps
      "agents": [...],
      "subtasks": [{"id","name","subtask_objective","agent","steps":[...]} ...]
    }
  }

Training:
- User sees Input + OutputSkeleton (from input.output)
- Target is full {"output": <ground truth output>}

Generation:
- Model should return complete "output" object (agents/subtasks same as skeleton, with steps filled).
"""

import os, json, random
from pathlib import Path
from collections import OrderedDict

import pandas as pd
import torch
from datasets import Dataset
from transformers import (
    AutoTokenizer,
    AutoModelForCausalLM,
    Trainer,
    TrainingArguments,
    DataCollatorForSeq2Seq,
    TrainerCallback,
)
from modelscope import AutoTokenizer, AutoModelForCausalLM
from peft import LoraConfig, TaskType, get_peft_model

# 设置所有缓存到数据盘
os.environ['MODELSCOPE_CACHE'] = '/root/autodl-tmp/modelscope_cache'
os.environ['HUGGINGFACE_HUB_CACHE'] = '/root/autodl-tmp/huggingface_cache'
os.environ['TRANSFORMERS_CACHE'] = '/root/autodl-tmp/transformers_cache'
os.environ['HF_HOME'] = '/root/autodl-tmp/huggingface'

# 创建目录
os.makedirs('/root/autodl-tmp/modelscope_cache', exist_ok=True)
os.makedirs('/root/autodl-tmp/huggingface_cache', exist_ok=True)
os.makedirs('/root/autodl-tmp/transformers_cache', exist_ok=True)

model_cache_dir = "/root/autodl-tmp/modelscope_cache"

# ===================== 0. Global Config =====================

MODEL_NAME = "Qwen/Qwen3-32B"
MAX_LENGTH = 3072
OUTPUT_DIR = "./output_latest/qwen3-0.6b-lora_full_output_datafit"

TRAIN_FOLDER = "../dataset_latest_stage2/train"  # <<< your train *.jsonl folder
VAL_FOLDER   = "../dataset_latest_stage2/test"   # <<< your val   *.jsonl folder

# (可选) 是否在训练前规范键顺序，提升一致性
ENABLE_REORDER = True


# ===================== 1. Prompt (Full Rewrite) =====================

PROMPT = """
You are an AI Architect for personalized, multi-agent programming instruction.

TASK
Given:
1) The learner input (query + learner profile), and
2) An OutputSkeleton that ALREADY includes the final set of agents and subtasks (each subtask has id/name/subtask_objective/agent but NO steps),

Return ONLY the final JSON object named "output" with the SAME agents and subtasks as the skeleton, but with a filled "steps" array for EACH subtask.

HARD CONSTRAINTS
- DO NOT change, remove, or add any agents or subtasks from the skeleton (id/name/subtask_objective/agent must remain identical).
- For each subtask, steps MUST use ONLY tools that exist in that subtask’s assigned agent’s tools.
- Step IDs MUST follow "<SubtaskID>-<running number>" (e.g., S3-1, S3-2).
- "depends_on" MUST reference existing step IDs (prefer previous steps in the SAME subtask) and be acyclic.
- If a subtask logically needs no steps, return an empty array for that subtask’s "steps".

RETURN FORMAT (JSON only)
{
  "output": {
    "agents": [ ... exactly from the skeleton ... ],
    "subtasks": [
      {
        "id": "S1",
        "name": "...",
        "subtask_objective": "...",
        "agent": "<unchanged>",
        "steps": [
          {"id":"S1-1","objective":"<specific task>","tool":"<tool from assigned agent>","depends_on":[]},
          {"id":"S1-2","objective":"...","tool":"<tool>","depends_on":["S1-1"]}
        ]
      },
      ...
    ]
  }
}

REFLECTION (internal)
- Validate tool usage against the assigned agent’s tools.
- Validate step IDs and depends_on correctness.
- Fix internally if any violation is detected.

Think step-by-step internally, but output ONLY the final JSON.
""".strip()


# ===================== 2. Utils =====================

def load_jsonl_folder(folder_path: str) -> pd.DataFrame:
    folder = Path(folder_path)
    all_data = []
    for fp in folder.glob("*.jsonl"):
        with open(fp, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    all_data.append(json.loads(line))
                except Exception as e:
                    print(f"[WARN] {fp.name} skip line: {e}")
    if not all_data:
        print(f"[WARN] No data loaded from {folder_path}")
    return pd.DataFrame(all_data)

def strip_steps_from_subtasks(subtasks):
    """Remove steps if mistakenly present in the skeleton; keep other fields & order."""
    new_list = []
    for s in subtasks or []:
        if isinstance(s, dict):
            d = OrderedDict()
            for k in ["id", "name", "subtask_objective", "agent"]:
                if k in s: d[k] = s[k]
            # keep any extra non-steps fields
            for k, v in s.items():
                if k not in d and k != "steps":
                    d[k] = v
            new_list.append(d)
        else:
            new_list.append(s)
    return new_list

def reorder_output(output: dict) -> dict:
    """Normalize key order to reduce formatting noise (optional)."""
    def order_agent(a: dict) -> OrderedDict:
        keys = ["agent_role", "goal", "description", "tools"]
        od = OrderedDict()
        for k in keys:
            if k in a: od[k] = a[k]
        for k, v in a.items():
            if k not in od: od[k] = v
        return od

    def order_subtask(s: dict) -> OrderedDict:
        keys = ["id", "name", "subtask_objective", "agent", "steps"]
        od = OrderedDict()
        for k in keys:
            if k in s: od[k] = s[k]
        for k, v in s.items():
            if k not in od: od[k] = v
        # steps inner order
        if "steps" in od and isinstance(od["steps"], list):
            new_steps = []
            for st in od["steps"]:
                if isinstance(st, dict):
                    step_keys = ["id", "objective", "tool", "depends_on"]
                    st_od = OrderedDict()
                    for kk in step_keys:
                        if kk in st: st_od[kk] = st[kk]
                    for kk, vv in st.items():
                        if kk not in st_od: st_od[kk] = vv
                    new_steps.append(st_od)
                else:
                    new_steps.append(st)
            od["steps"] = new_steps
        return od

    out = dict(output) if output else {}
    if "agents" in out and isinstance(out["agents"], list):
        out["agents"] = [order_agent(a) if isinstance(a, dict) else a for a in out["agents"]]
    if "subtasks" in out and isinstance(out["subtasks"], list):
        out["subtasks"] = [order_subtask(s) if isinstance(s, dict) else s for s in out["subtasks"]]
    return out

def sanitize_skeleton(skel: dict) -> dict:
    """Ensure skeleton has no steps; keep order stable."""
    skel = dict(skel) if skel else {}
    skel_agents = skel.get("agents", [])
    skel_subtasks = strip_steps_from_subtasks(skel.get("subtasks", []))
    return {"agents": skel_agents, "subtasks": skel_subtasks}


# ===================== 3. Preprocess =====================

def build_training_example(example, tokenizer):
    """
    Fits YOUR dataset shape:
      skeleton = example["input"]["output"]  # agents + subtasks (no steps)
      gt_output = example["output"]          # full output with steps
    """
    user_input = {
        "query":   example["input"]["query"],
        "learner": example["input"]["learner"],
    }
    skeleton_in_input = example["input"].get("output", {})  # <-- your skeleton
    skeleton = sanitize_skeleton(skeleton_in_input)

    gt_output = example["output"]
    if ENABLE_REORDER:
        gt_output = reorder_output(gt_output)

    # dialog
    system = f"<|im_start|>system\n{PROMPT}<|im_end|>\n"
    user = (
        "<|im_start|>user\n"
        f"Input: {json.dumps(user_input, ensure_ascii=False)}\n"
        f"OutputSkeleton: {json.dumps(skeleton, ensure_ascii=False)}\n"
        "<|im_end|>\n"
    )
    assistant = "<|im_start|>assistant\n"
    context_text = system + user + assistant

    # encode
    context_enc = tokenizer(context_text, add_special_tokens=False)
    target_obj = {"output": gt_output}   # <-- full output as training target
    target_text = json.dumps(target_obj, ensure_ascii=False)
    response_enc = tokenizer(target_text, add_special_tokens=False)

    input_ids = context_enc["input_ids"] + response_enc["input_ids"] + [tokenizer.eos_token_id]
    attention_mask = context_enc["attention_mask"] + response_enc["attention_mask"] + [1]
    labels = [-100] * len(context_enc["input_ids"]) + response_enc["input_ids"] + [tokenizer.eos_token_id]

    # truncate
    if len(input_ids) > MAX_LENGTH:
        input_ids = input_ids[:MAX_LENGTH]
        attention_mask = attention_mask[:MAX_LENGTH]
        labels = labels[:MAX_LENGTH]

    return {"input_ids": input_ids, "attention_mask": attention_mask, "labels": labels}

def process_func(example):
    return build_training_example(example, tokenizer)


# ===================== 4. Online Sanity Check Callback =====================

class InferenceCallback(TrainerCallback):
    def __init__(self, tokenizer, raw_eval_dataset, prompt_text,
                 every_n_steps=200, max_retries=3, max_new_tokens=512):
        self.tokenizer = tokenizer
        self.raw_eval_dataset = raw_eval_dataset  # UNMAPPED eval dataset (has input/output)
        self.prompt_text = prompt_text
        self.every_n_steps = every_n_steps
        self.max_retries = max_retries
        self.max_new_tokens = max_new_tokens

    def _build_input_text(self, sample):
        user_input = {
            "query":   sample["input"]["query"],
            "learner": sample["input"]["learner"],
        }
        skeleton = sanitize_skeleton(sample["input"].get("output", {}))
        system = f"<|im_start|>system\n{self.prompt_text}<|im_end|>\n"
        user = (
            "<|im_start|>user\n"
            f"Input: {json.dumps(user_input, ensure_ascii=False)}\n"
            f"OutputSkeleton: {json.dumps(skeleton, ensure_ascii=False)}\n"
            "<|im_end|>\n"
        )
        assistant = "<|im_start|>assistant\n"
        return system + user + assistant

    def on_step_end(self, args, state, control, **kwargs):
        model = kwargs.get("model")
        if model is None: return
        if state.global_step == 0 or state.global_step % self.every_n_steps != 0: return

        print(f"\n[Sanity Check @ step {state.global_step}]")
        retries, success = 0, False
        while retries < self.max_retries and not success:
            try:
                idx = random.randint(0, len(self.raw_eval_dataset) - 1)
                sample = self.raw_eval_dataset[idx]

                text = self._build_input_text(sample)
                inputs = self.tokenizer([text], return_tensors="pt").to(model.device)

                was_training = model.training
                model.eval()
                with torch.no_grad():
                    outputs = model.generate(
                        **inputs,
                        max_new_tokens=self.max_new_tokens,
                        eos_token_id=self.tokenizer.eos_token_id,
                        pad_token_id=self.tokenizer.eos_token_id,
                    )
                if was_training: model.train()

                resp = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
                print(f"[Eval idx={idx}] Query: {sample['input']['query']}")
                print("Response:\n", resp)
                success = True
            except Exception as e:
                print(f"[Warning] retry {retries+1}: {e}")
                retries += 1
        if not success:
            print("[Error] Sanity check failed after retries.]")


# ===================== 5. Main =====================

if __name__ == "__main__":
    # 1) tokenizer & base model
    tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME, use_fast=False, trust_remote_code=True,
                                             cache_dir=model_cache_dir)
    if tokenizer.pad_token is None:                                           
        tokenizer.pad_token = tokenizer.eos_token   
    model = AutoModelForCausalLM.from_pretrained(
        MODEL_NAME,
        device_map="auto",
        torch_dtype=torch.bfloat16,
        trust_remote_code=True,
        cache_dir=model_cache_dir
    )
    # model.enable_input_require_grads()
    model.gradient_checkpointing_enable()
    # 2) LoRA
    lora_config = LoraConfig(
        task_type=TaskType.CAUSAL_LM,
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
        inference_mode=False,
        r=16,
        lora_alpha=32,
        lora_dropout=0.05,
    )
    model = get_peft_model(model, lora_config)

    # 3) Load data
    train_df = load_jsonl_folder(TRAIN_FOLDER)
    val_df   = load_jsonl_folder(VAL_FOLDER)

    train_ds_raw = Dataset.from_pandas(train_df)  # raw for callback
    val_ds_raw   = Dataset.from_pandas(val_df)

    # tokenized datasets for Trainer
    train_dataset = train_ds_raw.map(lambda ex: build_training_example(ex, tokenizer),
                                     remove_columns=train_ds_raw.column_names)
    eval_dataset  = val_ds_raw.map(lambda ex: build_training_example(ex, tokenizer),
                                   remove_columns=val_ds_raw.column_names)

    print(f"Train samples: {len(train_dataset)} | Val samples: {len(eval_dataset)}")

    # 4) Training args
    args = TrainingArguments(
        output_dir=OUTPUT_DIR,
        per_device_train_batch_size=2,
        per_device_eval_batch_size=1,
        gradient_accumulation_steps=32,
        eval_strategy="steps",
        eval_steps=20,
        logging_steps=20,
        num_train_epochs=2,
        save_steps=40,
        learning_rate=1e-4,
        weight_decay=0.01,
        lr_scheduler_type="cosine",
        warmup_ratio=0.02,
        max_grad_norm=1.0,        
        gradient_checkpointing=True,
        bf16=True,
        fp16=False, 
        report_to="tensorboard",
        run_name="qwen3-32b-lora_full_output_datafit",
        save_total_limit=2,
        remove_unused_columns=False,
        resume_from_checkpoint=True,
        # fp16=False,  # Using bfloat16 weights above; toggle as needed
    )

    # 5) Trainer
    data_collator = DataCollatorForSeq2Seq(tokenizer=tokenizer, padding=True, label_pad_token_id=-100)
    trainer = Trainer(
        model=model,
        args=args,
        train_dataset=train_dataset,
        eval_dataset=eval_dataset,
        data_collator=data_collator,
        callbacks=[InferenceCallback(tokenizer, val_ds_raw, PROMPT, every_n_steps=200)],
    )

    # 6) Train
    trainer.train()

    # 7) Save LoRA adapter
    final_dir = os.path.join(OUTPUT_DIR, "final")
    os.makedirs(final_dir, exist_ok=True)
    model.save_pretrained(final_dir)
    print(f" LoRA fine-tune done. Saved to {final_dir}")
